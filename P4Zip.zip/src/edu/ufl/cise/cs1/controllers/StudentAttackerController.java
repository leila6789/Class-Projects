package edu.ufl.cise.cs1.controllers;
import game.controllers.AttackerController;
import game.models.*;
//import java.awt.*;
import java.util.List;

public final class StudentAttackerController implements AttackerController
{

	public int update(Game game, long timeDue) {


		//code for the first level. gator can eat the available pills
		if (game.getLevel() == 0) {
			return
					game.getAttacker().getNextDir(game.getAttacker().getTargetNode(game.getPillList(), true), true);

		}

		if (game.getLevel() >= 1)
		{

			//catches nullpointerexception
			try
			{
				// calculates the nearest power pill
				Node target;
				List<Node> pills = game.getPowerPillList();
				if (!pills.isEmpty()) {
					target = game.getAttacker().getTargetNode(pills, true);
				}
				else
					target=null;
				//These variables calculate the distance from each defender to the attacker
				int d1Distance =
						game.getAttacker().getLocation().getPathDistance(game.getDefender(0).getLocation());
				int d2Distance =
						game.getAttacker().getLocation().getPathDistance(game.getDefender(1).getLocation());
				int d3Distance =
						game.getAttacker().getLocation().getPathDistance(game.getDefender(2).getLocation());
				int d4Distance =
						game.getAttacker().getLocation().getPathDistance(game.getDefender(3).getLocation());

				//makes the gator go to the bottom left pill every time
				if (game.checkPowerPill(bottomLPill) &&
						game.getAttacker().getLocation().getPathDistance(bottomLPill) < 10)
				{

					//makes the gator go to the first blue power pill when an enemy leaves the center pen
					if ((d1Distance <=20 && d1Distance > -1) ||
							(d2Distance <= 20 && d2Distance > -1) || (d3Distance <= 20 &&
							d3Distance > -1) || (d4Distance <= 20 && d4Distance > -1))
					{
						return game.getAttacker().getNextDir(bottomLPill,
								true);
					}
					return game.getAttacker().getReverse();
				}


				//makes the gator go to the nearest defender
				else if (game.getDefender(0).isVulnerable() ||
						game.getDefender(1).isVulnerable() || game.getDefender(2).isVulnerable() ||
						game.getDefender(3).isVulnerable())
				{
					//calculates closest defender
					int index = 0;
					int minimium = 10000;
					for (int i = 0; i < 4; i++)
					{

						//makes sure the gator doesn't eat a power pill to catch a defender
						if ((game.getDefender(0).isVulnerable() ||
								game.getDefender(1).isVulnerable() || game.getDefender(2).isVulnerable() ||
								game.getDefender(3).isVulnerable()) &&
								(game.getAttacker().getLocation().getPathDistance(target) < 4))
						{
							return game.getAttacker().getReverse();
						}
						//Gets the closest defender
						if
						((game.getDefender(i).getLocation().getPathDistance(game.getAttacker().getLocation()) < minimium) && game.getDefender(i).isVulnerable())
						{
							index = i;
							minimium =
									game.getDefender(i).getLocation().getPathDistance(game.getAttacker().getLocation
											());
						}
					}
					return
							game.getAttacker().getNextDir(game.getDefender(index).getLocation(), true);
				}

				//if the gator is close to a power pill and defenders are not near, the gator will go in a back and forth direction
				else if
				((game.getAttacker().getLocation().getPathDistance(target) < 10) &&
				(d1Distance >10 && d2Distance > 10&& d3Distance > 10 && d4Distance > 10))
				{
					return game.getAttacker().getReverse();
				}
				return game.getAttacker().getNextDir(target, true);
			}
			//Catches the null pointer exception
			catch (NullPointerException ee)
			{
				//if a defender is vulnerable, catch the closest vulnerable defender
				if (game.getDefender(0).isVulnerable() ||
						game.getDefender(1).isVulnerable() || game.getDefender(2).isVulnerable() ||
						game.getDefender(3).isVulnerable())
				{
					int index = 0;
					int min= 10000;
					for (int i = 0; i < 4; i++)
					{
						if ((game.getDefender(i).isVulnerable() &&
								game.getDefender(i).getLocation().getPathDistance(game.getAttacker().getLocation
										()) < min))
						{
							index = i;
							min =
									game.getDefender(index).getLocation().getPathDistance(game.getAttacker().getLocation());
						}
					}
					return
							game.getAttacker().getNextDir(game.getDefender(index).getLocation(), true);
				}
				//if all of the power pills have been eaten, go to the closest pellet without changing any direction
				if
				(game.getAttacker().getNextDir(game.getAttacker().getTargetNode(game.getPillList
						(), true), true) == game.getAttacker().getReverse())
				{
					if (game.getAttacker().getLocation().isJunction())
					{
						return game.getAttacker().getPossibleDirs(false).get(0);
					}
					return game.getAttacker().getDirection();
				}
				return
						game.getAttacker().getNextDir(game.getAttacker().getTargetNode(game.getPillList(
						), true), true);
			}
		}
		return -1;
	}



	public void shutdown(Game game) {
	}

	public void init(Game game) {
		bottomLPill = game.getPowerPillList().get(3);
	}

	private Node bottomLPill;
}


